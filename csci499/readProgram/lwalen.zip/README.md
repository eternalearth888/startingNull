Final Project
=============
the github repository of the team hippaforalkus, whose members are notorious

Group Members
-------------
* Craig Carlson
* Kyle Leuenberger
* Michael Mason
* Lars Walen
