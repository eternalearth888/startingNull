package exercises;

public class Node{
	public int data;
	public Node left;
	public Node right;
	
	public Node(int newData) {
		data = newData;
		left = null;
		right = null;
	}
}
